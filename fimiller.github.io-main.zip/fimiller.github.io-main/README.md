Template is from https://github.com/yaoyao-liu/minimal-light
